<?php
session_start();
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
</head>
<body>
    <h1 class="title">Cadastro de Carros</h1>
    <a href="./cadastrar.php"><button >Cadastrar carros </button></a>
    <a href="./cadastro.php"><button >Ver carros cadastrados</button></a>
    <a href="./saida.php" ><button >saida</button></a>
    <br>
    




</body>
</html>

